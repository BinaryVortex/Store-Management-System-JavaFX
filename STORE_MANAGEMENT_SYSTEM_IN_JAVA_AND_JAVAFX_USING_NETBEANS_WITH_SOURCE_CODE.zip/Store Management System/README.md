# StoreKeeper
Inventory Menagement System in JavaFX, MySql

Storekeeper Alpha 0.5 is released .
